self.__precacheManifest = [
  {
    "revision": "acdfcc8db837016638e0",
    "url": "/AlexseyKurov/-/static/css/main.5ab3cc2c.chunk.css"
  },
  {
    "revision": "acdfcc8db837016638e0",
    "url": "/AlexseyKurov/-/static/js/main.31d321b7.chunk.js"
  },
  {
    "revision": "f511bac3f7a6ba524bde",
    "url": "/AlexseyKurov/-/static/js/runtime~main.d3a3ae6f.js"
  },
  {
    "revision": "2e8788f0523e22361aa5",
    "url": "/AlexseyKurov/-/static/css/2.8af8142f.chunk.css"
  },
  {
    "revision": "2e8788f0523e22361aa5",
    "url": "/AlexseyKurov/-/static/js/2.45ff4094.chunk.js"
  },
  {
    "revision": "46cdc006d35576d49786e01dccd6c142",
    "url": "/AlexseyKurov/-/index.html"
  }
];